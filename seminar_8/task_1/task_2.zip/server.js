const express=require('express')
const Carte=require('./Carte')

const app=express()

const lista_carti = [
    new Carte(1, 'Enigma Otiliei', 'George Calinescu','Roman'),
    new Carte(2, 'Ion', 'Liviu Rebreanu', 'Roman'),
    new Carte(3, 'Morometii', 'Marin Preda','Roman'),
    new Carte(4, 'Patul lui Procust', 'Camil Petrescu','Roman'),
    new Carte(5, 'Ultima noapte de dragoste, intaia noapte de razboi', 'Camil Petrescu','Roman'),
    new Carte(6, 'Cel mai iubit dintre pamanteni', 'Marin Preda','Roman'),
    new Carte(7, 'Baltagul', 'Mihail Sadoveanu','Roman'),
]
let cnt=8;
function sortare_carti_dupa_titlu(){
    return [...lista_carti].sort((a,b)=> a.titlu.localeCompare(b.titlu))
}
app.use(express.json());
app.get('/carti',(req,resp)=>{
    resp.json(sortare_carti_dupa_titlu());
})
app.post('/carti',(req,resp)=>{
    const {titlu,autor}=req.body;
    if(!titlu || titlu.trim()===''){
        return resp.status(400).json({error:'Titlul lipseste'});
    }
    if(!autor || autor.trim()===''){
        return resp.status(400).json({error:'Autorul lipseste'});
    }
    if(typeof titlu!=='string' || typeof autor!=='string'){
        return resp.status(400).json({error:'Titlu + Autor = > text'});
    } 
    const checkerCarte=CaretPosition.find(c=>
        c.titlu.toLowerCase()===titlu.toLowerCase().trim()
        && c.autor.toLowerCase()===autor.toLowerCase().trim()
    );
    if(checkerCarte){
        return resp.status(400).json({error:'Carte duplicata'})
    }
    const obiect_nou=new Carte(cnt,titlu.trim(),autor.trim(),'Roman');
    lista_carti.push(obiect_nou);
    
})
app.listen(34223,()=>console.log(`Serverul ruleaza pe portul ${34223}`))
