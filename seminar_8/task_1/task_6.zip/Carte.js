class Carte{
    constructor(id,titlu,autor,gen){
        this.id=id
        this.titlu=titlu
        this.autor=autor
        this.gen=gen
    }
 
}
module.exports=Carte;